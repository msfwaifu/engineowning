#include "EO_Main.h"

cg_t	*				cg				= (cg_t *)					0x9DC3A0;
cgs_t	*				cgs				= (cgs_t *)					0x9D7E20;
clientInfo_t *			clientinfo		= (clientInfo_t *)			0xAD9A78;
centity_t	*			cg_entities		= (centity_t *)				0xAE59C0;
refdef_t *				refdef			= (refdef_t *)				0xA475B0;
ViewMatrix_t *			viewmatrix		= (ViewMatrix_t *)			0x1140FEC;
EngineTags_t *			tags			= (EngineTags_t *)			0x1D69400;