#include "EO_Main.h"

EO_CClient EO_Client;


void EO_CClient::R_EndFrame( )
{
	if(cg->isInGame)
	{
		viewmatrix->Recoil[ 0 ] = 0;
		viewmatrix->Recoil[ 1 ] = 0;
		viewmatrix->Recoil[ 2 ] = 0;

		EO_Draw.DrawRect(400,400,400,400,10,RED);
		EO_Draw.DrawString(450,450,normalFont,1,GREEN,"TEST..");
	}
}

extern void FixSpread();

void EO_CClient::CL_WritePacket( )
{
	if(cg->isInGame)
	{

	}
}