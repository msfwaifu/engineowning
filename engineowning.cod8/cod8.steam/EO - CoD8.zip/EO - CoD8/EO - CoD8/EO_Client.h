class EO_CClient
{
public:

	void R_EndFrame( );
	void CL_WritePacket();
}extern EO_Client;