#include "EO_Main.h"

LONG CALLBACK pVEH_Hook( PEXCEPTION_POINTERS pInfo )
{
	if( pInfo->ContextRecord->Eip == 0x4F9FB9 )
	{
		EO_Client.R_EndFrame();
		pInfo->ContextRecord->Ecx = ( DWORD ) 0x5AC46C8;
		return EXCEPTION_CONTINUE_EXECUTION;
	}
	else if( pInfo->ContextRecord->Eip == 0x4040CA )
	{
		EO_Client.CL_WritePacket();
		pInfo->ContextRecord->Ecx = 0x5AB5E54;
		return EXCEPTION_CONTINUE_EXECUTION;
	}
	return EXCEPTION_CONTINUE_SEARCH;
}

void dwMainThread( )
{
	EO_Draw.InitializeDrawing();
	Sleep( 2000 );

	AddVectoredExceptionHandler( TRUE,pVEH_Hook );

	while( TRUE )
	{
		*reinterpret_cast< PDWORD_PTR >( 0x9DC394 ) = 0;
		*reinterpret_cast< PDWORD_PTR >( 0x113D96C ) = 0;
		Sleep( 2000 );
	}
}

void InitThread( void )
{
	CreateThread( NULL, NULL, ( LPTHREAD_START_ROUTINE )dwMainThread, NULL, NULL, NULL );
}