class EO_CUtils
{
public:
	int 			SetupVectorTrace		(float *flLocation);
	float			GetDistance				( vec3_t A, vec3_t B );
	float			Get2dDistance			( vec2_t A, vec2_t B );
	bool			WorldToScreen			( vec3_t vWorldLocation,float Screen[2] );
	void			AngleVectors			( const vec3_t angles, vec3_t forward, vec3_t right, vec3_t up );
	void			vectoangles				( const vec3_t value1, vec3_t angles );
	float			AngleNormalize180		( float angle );
	float			AngleNormalize360		( float angle );
	void			VectorViewAngles		(float *flLocation,float *flOut);
	bool			GetPlayerTag			(short tag, centity_t* entity, float* vec);
	bool			NormalTrace				( vec3_t point, centity_t* pEntity);
};
extern EO_CUtils		EO_Utils;