
extern void CG_DrawFPS();

extern void CG_PredictedPlayerState();

extern int vPPS;

extern int vDFPS;